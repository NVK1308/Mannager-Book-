﻿namespace QLThuVien.Form_Info
{
    partial class frm_TTTS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.txt_SL = new DevExpress.XtraEditors.TextEdit();
            this.txt_VT = new DevExpress.XtraEditors.TextEdit();
            this.txt_NXB = new DevExpress.XtraEditors.TextEdit();
            this.txt_TG = new DevExpress.XtraEditors.TextEdit();
            this.txt_ST = new DevExpress.XtraEditors.TextEdit();
            this.txt_XB = new DevExpress.XtraEditors.TextEdit();
            this.txt_TL = new DevExpress.XtraEditors.TextEdit();
            this.txt_TenTS = new DevExpress.XtraEditors.TextEdit();
            this.txt_MaTS = new DevExpress.XtraEditors.TextEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.lci_MaTS = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_TenTS = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_TL = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_TG = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_ST = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_XB = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_VT = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_SL = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_NXB = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_VT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NXB.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TG.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_ST.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_XB.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TenTS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaTS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_MaTS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_TenTS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_TL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_TG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_ST)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_XB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_VT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_SL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_NXB)).BeginInit();
            this.SuspendLayout();
            // 
            // layoutControl1
            // 
            this.layoutControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.layoutControl1.Controls.Add(this.txt_SL);
            this.layoutControl1.Controls.Add(this.txt_VT);
            this.layoutControl1.Controls.Add(this.txt_NXB);
            this.layoutControl1.Controls.Add(this.txt_TG);
            this.layoutControl1.Controls.Add(this.txt_ST);
            this.layoutControl1.Controls.Add(this.txt_XB);
            this.layoutControl1.Controls.Add(this.txt_TL);
            this.layoutControl1.Controls.Add(this.txt_TenTS);
            this.layoutControl1.Controls.Add(this.txt_MaTS);
            this.layoutControl1.Location = new System.Drawing.Point(12, 6);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.layoutControlGroup1;
            this.layoutControl1.Size = new System.Drawing.Size(534, 195);
            this.layoutControl1.TabIndex = 0;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // txt_SL
            // 
            this.txt_SL.Location = new System.Drawing.Point(424, 152);
            this.txt_SL.Name = "txt_SL";
            this.txt_SL.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SL.Properties.Appearance.Options.UseFont = true;
            this.txt_SL.Size = new System.Drawing.Size(98, 24);
            this.txt_SL.StyleController = this.layoutControl1;
            this.txt_SL.TabIndex = 12;
            // 
            // txt_VT
            // 
            this.txt_VT.Location = new System.Drawing.Point(105, 96);
            this.txt_VT.Name = "txt_VT";
            this.txt_VT.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_VT.Properties.Appearance.Options.UseFont = true;
            this.txt_VT.Size = new System.Drawing.Size(222, 24);
            this.txt_VT.StyleController = this.layoutControl1;
            this.txt_VT.TabIndex = 11;
            // 
            // txt_NXB
            // 
            this.txt_NXB.Location = new System.Drawing.Point(105, 152);
            this.txt_NXB.Name = "txt_NXB";
            this.txt_NXB.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NXB.Properties.Appearance.Options.UseFont = true;
            this.txt_NXB.Size = new System.Drawing.Size(222, 24);
            this.txt_NXB.StyleController = this.layoutControl1;
            this.txt_NXB.TabIndex = 10;
            // 
            // txt_TG
            // 
            this.txt_TG.Location = new System.Drawing.Point(105, 124);
            this.txt_TG.Name = "txt_TG";
            this.txt_TG.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TG.Properties.Appearance.Options.UseFont = true;
            this.txt_TG.Size = new System.Drawing.Size(417, 24);
            this.txt_TG.StyleController = this.layoutControl1;
            this.txt_TG.TabIndex = 9;
            // 
            // txt_ST
            // 
            this.txt_ST.Location = new System.Drawing.Point(424, 96);
            this.txt_ST.Name = "txt_ST";
            this.txt_ST.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ST.Properties.Appearance.Options.UseFont = true;
            this.txt_ST.Size = new System.Drawing.Size(98, 24);
            this.txt_ST.StyleController = this.layoutControl1;
            this.txt_ST.TabIndex = 8;
            // 
            // txt_XB
            // 
            this.txt_XB.Location = new System.Drawing.Point(424, 68);
            this.txt_XB.Name = "txt_XB";
            this.txt_XB.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_XB.Properties.Appearance.Options.UseFont = true;
            this.txt_XB.Size = new System.Drawing.Size(98, 24);
            this.txt_XB.StyleController = this.layoutControl1;
            this.txt_XB.TabIndex = 7;
            // 
            // txt_TL
            // 
            this.txt_TL.Location = new System.Drawing.Point(105, 68);
            this.txt_TL.Name = "txt_TL";
            this.txt_TL.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TL.Properties.Appearance.Options.UseFont = true;
            this.txt_TL.Size = new System.Drawing.Size(222, 24);
            this.txt_TL.StyleController = this.layoutControl1;
            this.txt_TL.TabIndex = 6;
            // 
            // txt_TenTS
            // 
            this.txt_TenTS.Location = new System.Drawing.Point(105, 40);
            this.txt_TenTS.Name = "txt_TenTS";
            this.txt_TenTS.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TenTS.Properties.Appearance.Options.UseFont = true;
            this.txt_TenTS.Size = new System.Drawing.Size(417, 24);
            this.txt_TenTS.StyleController = this.layoutControl1;
            this.txt_TenTS.TabIndex = 5;
            // 
            // txt_MaTS
            // 
            this.txt_MaTS.Location = new System.Drawing.Point(105, 12);
            this.txt_MaTS.Name = "txt_MaTS";
            this.txt_MaTS.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaTS.Properties.Appearance.Options.UseFont = true;
            this.txt_MaTS.Size = new System.Drawing.Size(417, 24);
            this.txt_MaTS.StyleController = this.layoutControl1;
            this.txt_MaTS.TabIndex = 4;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lci_MaTS,
            this.lci_TenTS,
            this.lci_TL,
            this.lci_TG,
            this.lci_ST,
            this.lci_XB,
            this.lci_VT,
            this.lci_SL,
            this.lci_NXB});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "layoutControlGroup1";
            this.layoutControlGroup1.Size = new System.Drawing.Size(534, 195);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // lci_MaTS
            // 
            this.lci_MaTS.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_MaTS.AppearanceItemCaption.Options.UseFont = true;
            this.lci_MaTS.Control = this.txt_MaTS;
            this.lci_MaTS.Location = new System.Drawing.Point(0, 0);
            this.lci_MaTS.Name = "lci_MaTS";
            this.lci_MaTS.Size = new System.Drawing.Size(514, 28);
            this.lci_MaTS.Text = "Mã tựa sách";
            this.lci_MaTS.TextSize = new System.Drawing.Size(90, 17);
            // 
            // lci_TenTS
            // 
            this.lci_TenTS.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_TenTS.AppearanceItemCaption.Options.UseFont = true;
            this.lci_TenTS.Control = this.txt_TenTS;
            this.lci_TenTS.Location = new System.Drawing.Point(0, 28);
            this.lci_TenTS.Name = "lci_TenTS";
            this.lci_TenTS.Size = new System.Drawing.Size(514, 28);
            this.lci_TenTS.Text = "Tên tựa sách";
            this.lci_TenTS.TextSize = new System.Drawing.Size(90, 17);
            // 
            // lci_TL
            // 
            this.lci_TL.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_TL.AppearanceItemCaption.Options.UseFont = true;
            this.lci_TL.Control = this.txt_TL;
            this.lci_TL.Location = new System.Drawing.Point(0, 56);
            this.lci_TL.Name = "lci_TL";
            this.lci_TL.Size = new System.Drawing.Size(319, 28);
            this.lci_TL.Text = "Thể loại";
            this.lci_TL.TextSize = new System.Drawing.Size(90, 17);
            // 
            // lci_TG
            // 
            this.lci_TG.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_TG.AppearanceItemCaption.Options.UseFont = true;
            this.lci_TG.Control = this.txt_TG;
            this.lci_TG.Location = new System.Drawing.Point(0, 112);
            this.lci_TG.Name = "lci_TG";
            this.lci_TG.Size = new System.Drawing.Size(514, 28);
            this.lci_TG.Text = "Tác giả";
            this.lci_TG.TextSize = new System.Drawing.Size(90, 17);
            // 
            // lci_ST
            // 
            this.lci_ST.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_ST.AppearanceItemCaption.Options.UseFont = true;
            this.lci_ST.Control = this.txt_ST;
            this.lci_ST.Location = new System.Drawing.Point(319, 84);
            this.lci_ST.Name = "lci_ST";
            this.lci_ST.Size = new System.Drawing.Size(195, 28);
            this.lci_ST.Text = "Số trang";
            this.lci_ST.TextSize = new System.Drawing.Size(90, 17);
            // 
            // lci_XB
            // 
            this.lci_XB.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_XB.AppearanceItemCaption.Options.UseFont = true;
            this.lci_XB.Control = this.txt_XB;
            this.lci_XB.Location = new System.Drawing.Point(319, 56);
            this.lci_XB.Name = "lci_XB";
            this.lci_XB.Size = new System.Drawing.Size(195, 28);
            this.lci_XB.Text = "Năm XB";
            this.lci_XB.TextSize = new System.Drawing.Size(90, 17);
            // 
            // lci_VT
            // 
            this.lci_VT.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_VT.AppearanceItemCaption.Options.UseFont = true;
            this.lci_VT.Control = this.txt_VT;
            this.lci_VT.Location = new System.Drawing.Point(0, 84);
            this.lci_VT.Name = "lci_VT";
            this.lci_VT.Size = new System.Drawing.Size(319, 28);
            this.lci_VT.Text = "Vị trí";
            this.lci_VT.TextSize = new System.Drawing.Size(90, 17);
            // 
            // lci_SL
            // 
            this.lci_SL.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_SL.AppearanceItemCaption.Options.UseFont = true;
            this.lci_SL.Control = this.txt_SL;
            this.lci_SL.Location = new System.Drawing.Point(319, 140);
            this.lci_SL.Name = "lci_SL";
            this.lci_SL.Size = new System.Drawing.Size(195, 35);
            this.lci_SL.Text = "Số lượng sách";
            this.lci_SL.TextSize = new System.Drawing.Size(90, 17);
            // 
            // lci_NXB
            // 
            this.lci_NXB.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_NXB.AppearanceItemCaption.Options.UseFont = true;
            this.lci_NXB.Control = this.txt_NXB;
            this.lci_NXB.Location = new System.Drawing.Point(0, 140);
            this.lci_NXB.Name = "lci_NXB";
            this.lci_NXB.Size = new System.Drawing.Size(319, 35);
            this.lci_NXB.Text = "Nhà XB";
            this.lci_NXB.TextSize = new System.Drawing.Size(90, 17);
            // 
            // frm_TTTS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 202);
            this.Controls.Add(this.layoutControl1);
            this.Name = "frm_TTTS";
            this.Text = "frm_TTTS";
            this.Load += new System.EventHandler(this.frm_TTTS_Load);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txt_SL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_VT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NXB.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TG.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_ST.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_XB.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TenTS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaTS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_MaTS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_TenTS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_TL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_TG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_ST)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_XB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_VT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_SL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_NXB)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraEditors.TextEdit txt_SL;
        private DevExpress.XtraEditors.TextEdit txt_VT;
        private DevExpress.XtraEditors.TextEdit txt_NXB;
        private DevExpress.XtraEditors.TextEdit txt_TG;
        private DevExpress.XtraEditors.TextEdit txt_ST;
        private DevExpress.XtraEditors.TextEdit txt_XB;
        private DevExpress.XtraEditors.TextEdit txt_TL;
        private DevExpress.XtraEditors.TextEdit txt_TenTS;
        private DevExpress.XtraEditors.TextEdit txt_MaTS;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem lci_MaTS;
        private DevExpress.XtraLayout.LayoutControlItem lci_TenTS;
        private DevExpress.XtraLayout.LayoutControlItem lci_TL;
        private DevExpress.XtraLayout.LayoutControlItem lci_TG;
        private DevExpress.XtraLayout.LayoutControlItem lci_ST;
        private DevExpress.XtraLayout.LayoutControlItem lci_XB;
        private DevExpress.XtraLayout.LayoutControlItem lci_VT;
        private DevExpress.XtraLayout.LayoutControlItem lci_SL;
        private DevExpress.XtraLayout.LayoutControlItem lci_NXB;
    }
}