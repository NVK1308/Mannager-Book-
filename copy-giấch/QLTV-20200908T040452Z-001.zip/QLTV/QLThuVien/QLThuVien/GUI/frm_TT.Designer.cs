﻿namespace QLThuVien.GUI
{
    partial class frm_TT
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraLayout.LayoutControl layoutControl1;
            DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_TT));
            this.txt_CV = new DevExpress.XtraEditors.TextEdit();
            this.txt_SDT = new DevExpress.XtraEditors.TextEdit();
            this.cmb_GT = new DevExpress.XtraEditors.ComboBoxEdit();
            this.txt_DC = new DevExpress.XtraEditors.TextEdit();
            this.txt_TenTT = new DevExpress.XtraEditors.TextEdit();
            this.txt_MaTT = new DevExpress.XtraEditors.TextEdit();
            this.date_NS = new DevExpress.XtraEditors.DateEdit();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_NS = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_TenTT = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_DC = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_GT = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_SDT = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_CV = new DevExpress.XtraLayout.LayoutControlItem();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btn_cancel = new DevExpress.XtraEditors.SimpleButton();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.btn_save = new DevExpress.XtraEditors.SimpleButton();
            this.btn_delete = new DevExpress.XtraEditors.SimpleButton();
            this.btn_update = new DevExpress.XtraEditors.SimpleButton();
            this.btn_insert = new DevExpress.XtraEditors.SimpleButton();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            ((System.ComponentModel.ISupportInitialize)(layoutControl1)).BeginInit();
            layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_CV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmb_GT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_DC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TenTT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaTT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_NS.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_NS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_NS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_TenTT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_DC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_GT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_SDT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_CV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // layoutControl1
            // 
            layoutControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            layoutControl1.Controls.Add(this.txt_CV);
            layoutControl1.Controls.Add(this.txt_SDT);
            layoutControl1.Controls.Add(this.cmb_GT);
            layoutControl1.Controls.Add(this.txt_DC);
            layoutControl1.Controls.Add(this.txt_TenTT);
            layoutControl1.Controls.Add(this.txt_MaTT);
            layoutControl1.Controls.Add(this.date_NS);
            layoutControl1.Location = new System.Drawing.Point(23, 14);
            layoutControl1.Name = "layoutControl1";
            layoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(238, 169, 250, 350);
            layoutControl1.Root = layoutControlGroup1;
            layoutControl1.Size = new System.Drawing.Size(848, 139);
            layoutControl1.TabIndex = 0;
            layoutControl1.Text = "layoutControl1";
            // 
            // txt_CV
            // 
            this.txt_CV.Location = new System.Drawing.Point(93, 96);
            this.txt_CV.Name = "txt_CV";
            this.txt_CV.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CV.Properties.Appearance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_CV.Properties.Appearance.Options.UseFont = true;
            this.txt_CV.Properties.Appearance.Options.UseForeColor = true;
            this.txt_CV.Size = new System.Drawing.Size(292, 24);
            this.txt_CV.StyleController = layoutControl1;
            this.txt_CV.TabIndex = 10;
            // 
            // txt_SDT
            // 
            this.txt_SDT.Location = new System.Drawing.Point(470, 68);
            this.txt_SDT.Name = "txt_SDT";
            this.txt_SDT.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SDT.Properties.Appearance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_SDT.Properties.Appearance.Options.UseFont = true;
            this.txt_SDT.Properties.Appearance.Options.UseForeColor = true;
            this.txt_SDT.Size = new System.Drawing.Size(366, 24);
            this.txt_SDT.StyleController = layoutControl1;
            this.txt_SDT.TabIndex = 9;
            // 
            // cmb_GT
            // 
            this.cmb_GT.Location = new System.Drawing.Point(470, 40);
            this.cmb_GT.Name = "cmb_GT";
            this.cmb_GT.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_GT.Properties.Appearance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cmb_GT.Properties.Appearance.Options.UseFont = true;
            this.cmb_GT.Properties.Appearance.Options.UseForeColor = true;
            this.cmb_GT.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmb_GT.Properties.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.cmb_GT.Size = new System.Drawing.Size(366, 24);
            this.cmb_GT.StyleController = layoutControl1;
            this.cmb_GT.TabIndex = 8;
            // 
            // txt_DC
            // 
            this.txt_DC.Location = new System.Drawing.Point(93, 68);
            this.txt_DC.Name = "txt_DC";
            this.txt_DC.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DC.Properties.Appearance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_DC.Properties.Appearance.Options.UseFont = true;
            this.txt_DC.Properties.Appearance.Options.UseForeColor = true;
            this.txt_DC.Size = new System.Drawing.Size(292, 24);
            this.txt_DC.StyleController = layoutControl1;
            this.txt_DC.TabIndex = 6;
            // 
            // txt_TenTT
            // 
            this.txt_TenTT.Location = new System.Drawing.Point(470, 12);
            this.txt_TenTT.Name = "txt_TenTT";
            this.txt_TenTT.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TenTT.Properties.Appearance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_TenTT.Properties.Appearance.Options.UseFont = true;
            this.txt_TenTT.Properties.Appearance.Options.UseForeColor = true;
            this.txt_TenTT.Size = new System.Drawing.Size(366, 24);
            this.txt_TenTT.StyleController = layoutControl1;
            this.txt_TenTT.TabIndex = 5;
            // 
            // txt_MaTT
            // 
            this.txt_MaTT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_MaTT.Enabled = false;
            this.txt_MaTT.Location = new System.Drawing.Point(93, 12);
            this.txt_MaTT.Name = "txt_MaTT";
            this.txt_MaTT.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaTT.Properties.Appearance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_MaTT.Properties.Appearance.Options.UseFont = true;
            this.txt_MaTT.Properties.Appearance.Options.UseForeColor = true;
            this.txt_MaTT.Size = new System.Drawing.Size(292, 24);
            this.txt_MaTT.StyleController = layoutControl1;
            this.txt_MaTT.TabIndex = 4;
            // 
            // date_NS
            // 
            this.date_NS.EditValue = null;
            this.date_NS.Location = new System.Drawing.Point(93, 40);
            this.date_NS.Name = "date_NS";
            this.date_NS.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_NS.Properties.Appearance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.date_NS.Properties.Appearance.Options.UseFont = true;
            this.date_NS.Properties.Appearance.Options.UseForeColor = true;
            this.date_NS.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.date_NS.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.date_NS.Properties.Mask.BeepOnError = true;
            this.date_NS.Properties.Mask.IgnoreMaskBlank = false;
            this.date_NS.Size = new System.Drawing.Size(292, 24);
            this.date_NS.StyleController = layoutControl1;
            this.date_NS.TabIndex = 7;
            // 
            // layoutControlGroup1
            // 
            layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            layoutControlGroup1.GroupBordersVisible = false;
            layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.lci_NS,
            this.lci_TenTT,
            this.lci_DC,
            this.lci_GT,
            this.lci_SDT,
            this.lci_CV});
            layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            layoutControlGroup1.Name = "Root";
            layoutControlGroup1.Size = new System.Drawing.Size(848, 139);
            layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.layoutControlItem1.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.layoutControlItem1.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem1.AppearanceItemCaption.Options.UseForeColor = true;
            this.layoutControlItem1.Control = this.txt_MaTT;
            this.layoutControlItem1.ControlAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(377, 28);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.SupportHorzAlignment;
            this.layoutControlItem1.Text = "Mã Thủ thư";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(78, 17);
            // 
            // lci_NS
            // 
            this.lci_NS.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_NS.AppearanceItemCaption.Options.UseFont = true;
            this.lci_NS.Control = this.date_NS;
            this.lci_NS.ControlAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.lci_NS.Location = new System.Drawing.Point(0, 28);
            this.lci_NS.Name = "lci_NS";
            this.lci_NS.Size = new System.Drawing.Size(377, 28);
            this.lci_NS.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.SupportHorzAlignment;
            this.lci_NS.Text = "Ngày sinh";
            this.lci_NS.TextSize = new System.Drawing.Size(78, 17);
            // 
            // lci_TenTT
            // 
            this.lci_TenTT.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_TenTT.AppearanceItemCaption.Options.UseFont = true;
            this.lci_TenTT.Control = this.txt_TenTT;
            this.lci_TenTT.ControlAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.lci_TenTT.Location = new System.Drawing.Point(377, 0);
            this.lci_TenTT.Name = "lci_TenTT";
            this.lci_TenTT.Size = new System.Drawing.Size(451, 28);
            this.lci_TenTT.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.SupportHorzAlignment;
            this.lci_TenTT.Text = "Họ tên";
            this.lci_TenTT.TextSize = new System.Drawing.Size(78, 17);
            // 
            // lci_DC
            // 
            this.lci_DC.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_DC.AppearanceItemCaption.Options.UseFont = true;
            this.lci_DC.Control = this.txt_DC;
            this.lci_DC.ControlAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.lci_DC.Location = new System.Drawing.Point(0, 56);
            this.lci_DC.Name = "lci_DC";
            this.lci_DC.Size = new System.Drawing.Size(377, 28);
            this.lci_DC.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.SupportHorzAlignment;
            this.lci_DC.Text = "Địa chỉ";
            this.lci_DC.TextSize = new System.Drawing.Size(78, 17);
            // 
            // lci_GT
            // 
            this.lci_GT.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_GT.AppearanceItemCaption.Options.UseFont = true;
            this.lci_GT.Control = this.cmb_GT;
            this.lci_GT.ControlAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.lci_GT.Location = new System.Drawing.Point(377, 28);
            this.lci_GT.Name = "lci_GT";
            this.lci_GT.Size = new System.Drawing.Size(451, 28);
            this.lci_GT.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.SupportHorzAlignment;
            this.lci_GT.Text = "Giới tính";
            this.lci_GT.TextSize = new System.Drawing.Size(78, 17);
            // 
            // lci_SDT
            // 
            this.lci_SDT.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_SDT.AppearanceItemCaption.Options.UseFont = true;
            this.lci_SDT.Control = this.txt_SDT;
            this.lci_SDT.ControlAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.lci_SDT.Location = new System.Drawing.Point(377, 56);
            this.lci_SDT.Name = "lci_SDT";
            this.lci_SDT.Size = new System.Drawing.Size(451, 63);
            this.lci_SDT.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.SupportHorzAlignment;
            this.lci_SDT.Text = "Điện thoại";
            this.lci_SDT.TextSize = new System.Drawing.Size(78, 17);
            // 
            // lci_CV
            // 
            this.lci_CV.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_CV.AppearanceItemCaption.Options.UseFont = true;
            this.lci_CV.Control = this.txt_CV;
            this.lci_CV.ControlAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.lci_CV.Location = new System.Drawing.Point(0, 84);
            this.lci_CV.Name = "lci_CV";
            this.lci_CV.Size = new System.Drawing.Size(377, 35);
            this.lci_CV.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.SupportHorzAlignment;
            this.lci_CV.Text = "Chức vụ";
            this.lci_CV.TextSize = new System.Drawing.Size(78, 17);
            // 
            // panelControl1
            // 
            this.panelControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl1.Appearance.BackColor = System.Drawing.Color.White;
            this.panelControl1.Appearance.Options.UseBackColor = true;
            this.panelControl1.Controls.Add(this.btn_cancel);
            this.panelControl1.Controls.Add(this.txt_search);
            this.panelControl1.Controls.Add(this.btn_save);
            this.panelControl1.Controls.Add(this.btn_delete);
            this.panelControl1.Controls.Add(this.btn_update);
            this.panelControl1.Controls.Add(this.btn_insert);
            this.panelControl1.Location = new System.Drawing.Point(35, 159);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(825, 59);
            this.panelControl1.TabIndex = 4;
            // 
            // btn_cancel
            // 
            this.btn_cancel.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.Appearance.Options.UseFont = true;
            this.btn_cancel.Image = ((System.Drawing.Image)(resources.GetObject("btn_cancel.Image")));
            this.btn_cancel.Location = new System.Drawing.Point(426, 12);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(100, 35);
            this.btn_cancel.TabIndex = 18;
            this.btn_cancel.Text = "CANCEL";
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // txt_search
            // 
            this.txt_search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_search.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txt_search.Location = new System.Drawing.Point(532, 12);
            this.txt_search.Multiline = true;
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(271, 35);
            this.txt_search.TabIndex = 17;
            this.txt_search.Text = "Search";
            this.txt_search.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txt_search_MouseClick);
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // btn_save
            // 
            this.btn_save.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Appearance.Options.UseFont = true;
            this.btn_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_save.Image")));
            this.btn_save.Location = new System.Drawing.Point(320, 12);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(100, 35);
            this.btn_save.TabIndex = 15;
            this.btn_save.Text = "SAVE";
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Appearance.Options.UseFont = true;
            this.btn_delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_delete.Image")));
            this.btn_delete.Location = new System.Drawing.Point(214, 12);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(100, 35);
            this.btn_delete.TabIndex = 14;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Appearance.Options.UseFont = true;
            this.btn_update.Image = ((System.Drawing.Image)(resources.GetObject("btn_update.Image")));
            this.btn_update.Location = new System.Drawing.Point(108, 12);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(100, 35);
            this.btn_update.TabIndex = 13;
            this.btn_update.Text = "UPDATE";
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_insert.Appearance.Options.UseFont = true;
            this.btn_insert.Image = ((System.Drawing.Image)(resources.GetObject("btn_insert.Image")));
            this.btn_insert.Location = new System.Drawing.Point(2, 12);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(100, 35);
            this.btn_insert.TabIndex = 12;
            this.btn_insert.Text = "INSERT";
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // gridControl1
            // 
            this.gridControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridControl1.Location = new System.Drawing.Point(35, 224);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(825, 200);
            this.gridControl1.TabIndex = 5;
            this.gridControl1.UseEmbeddedNavigator = true;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7});
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridView1_FocusedRowChanged);
            this.gridView1.Click += new System.EventHandler(this.gridView1_Click);
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn1.AppearanceCell.Options.UseFont = true;
            this.gridColumn1.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn1.AppearanceHeader.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridColumn1.AppearanceHeader.Options.UseFont = true;
            this.gridColumn1.Caption = "Mã thủ thư";
            this.gridColumn1.FieldName = "MaTT";
            this.gridColumn1.MinWidth = 40;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn2.AppearanceCell.Options.UseFont = true;
            this.gridColumn2.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn2.AppearanceHeader.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridColumn2.AppearanceHeader.Options.UseFont = true;
            this.gridColumn2.Caption = "Họ tên";
            this.gridColumn2.FieldName = "TenTT";
            this.gridColumn2.MinWidth = 40;
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn3.AppearanceCell.Options.UseFont = true;
            this.gridColumn3.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn3.AppearanceHeader.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridColumn3.AppearanceHeader.Options.UseFont = true;
            this.gridColumn3.Caption = "Ngày sinh";
            this.gridColumn3.FieldName = "NgaySinh";
            this.gridColumn3.MinWidth = 40;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn4.AppearanceCell.Options.UseFont = true;
            this.gridColumn4.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn4.AppearanceHeader.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridColumn4.AppearanceHeader.Options.UseFont = true;
            this.gridColumn4.Caption = "Giới tính";
            this.gridColumn4.FieldName = "GioiTinh";
            this.gridColumn4.MinWidth = 40;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn5.AppearanceCell.Options.UseFont = true;
            this.gridColumn5.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn5.AppearanceHeader.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridColumn5.AppearanceHeader.Options.UseFont = true;
            this.gridColumn5.Caption = "Địa chỉ";
            this.gridColumn5.FieldName = "DiaChi";
            this.gridColumn5.MinWidth = 40;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn6.AppearanceCell.Options.UseFont = true;
            this.gridColumn6.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn6.AppearanceHeader.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridColumn6.AppearanceHeader.Options.UseFont = true;
            this.gridColumn6.Caption = "Điện thoại";
            this.gridColumn6.FieldName = "SDT";
            this.gridColumn6.MinWidth = 40;
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 5;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn7.AppearanceCell.Options.UseFont = true;
            this.gridColumn7.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn7.AppearanceHeader.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridColumn7.AppearanceHeader.Options.UseFont = true;
            this.gridColumn7.Caption = "Chức vụ";
            this.gridColumn7.FieldName = "Chucvu";
            this.gridColumn7.MinWidth = 40;
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 6;
            // 
            // frm_TT
            // 
            this.Appearance.BackColor = System.Drawing.Color.White;
            this.Appearance.ForeColor = System.Drawing.Color.Black;
            this.Appearance.Options.UseBackColor = true;
            this.Appearance.Options.UseForeColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(layoutControl1);
            this.Name = "frm_TT";
            this.Size = new System.Drawing.Size(900, 450);
            this.Load += new System.EventHandler(this.frm_TT_Load);
            ((System.ComponentModel.ISupportInitialize)(layoutControl1)).EndInit();
            layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txt_CV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmb_GT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_DC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TenTT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaTT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_NS.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_NS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_NS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_TenTT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_DC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_GT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_SDT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_CV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.TextEdit txt_MaTT;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private System.Windows.Forms.TextBox txt_search;
        private DevExpress.XtraEditors.SimpleButton btn_save;
        private DevExpress.XtraEditors.SimpleButton btn_delete;
        private DevExpress.XtraEditors.SimpleButton btn_update;
        private DevExpress.XtraEditors.SimpleButton btn_insert;
        private DevExpress.XtraEditors.TextEdit txt_CV;
        private DevExpress.XtraEditors.TextEdit txt_SDT;
        private DevExpress.XtraEditors.ComboBoxEdit cmb_GT;
        private DevExpress.XtraEditors.TextEdit txt_DC;
        private DevExpress.XtraEditors.TextEdit txt_TenTT;
        private DevExpress.XtraLayout.LayoutControlItem lci_NS;
        private DevExpress.XtraLayout.LayoutControlItem lci_TenTT;
        private DevExpress.XtraLayout.LayoutControlItem lci_DC;
        private DevExpress.XtraLayout.LayoutControlItem lci_GT;
        private DevExpress.XtraLayout.LayoutControlItem lci_SDT;
        private DevExpress.XtraLayout.LayoutControlItem lci_CV;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraEditors.SimpleButton btn_cancel;
        private DevExpress.XtraEditors.DateEdit date_NS;
    }
}
