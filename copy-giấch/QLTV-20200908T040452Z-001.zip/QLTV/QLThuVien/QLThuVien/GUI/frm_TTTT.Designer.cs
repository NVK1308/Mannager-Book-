﻿namespace QLThuVien.GUI
{
    partial class frm_TTTT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.txt_CV = new DevExpress.XtraEditors.TextEdit();
            this.txt_SDT = new DevExpress.XtraEditors.TextEdit();
            this.txt_DC = new DevExpress.XtraEditors.TextEdit();
            this.txt_GT = new DevExpress.XtraEditors.TextEdit();
            this.txt_TenTT = new DevExpress.XtraEditors.TextEdit();
            this.txt_MaTT = new DevExpress.XtraEditors.TextEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.lbl_MaTT = new DevExpress.XtraLayout.LayoutControlItem();
            this.lbl_TenTT = new DevExpress.XtraLayout.LayoutControlItem();
            this.lbl_GT = new DevExpress.XtraLayout.LayoutControlItem();
            this.lbl_DC = new DevExpress.XtraLayout.LayoutControlItem();
            this.lbl_SDT = new DevExpress.XtraLayout.LayoutControlItem();
            this.lbl_CV = new DevExpress.XtraLayout.LayoutControlItem();
            this.txt_NS = new DevExpress.XtraEditors.DateEdit();
            this.lbl_NS = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_CV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_DC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_GT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TenTT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaTT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_MaTT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_TenTT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_GT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_DC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_SDT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_CV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NS.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_NS)).BeginInit();
            this.SuspendLayout();
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.txt_NS);
            this.layoutControl1.Controls.Add(this.txt_CV);
            this.layoutControl1.Controls.Add(this.txt_SDT);
            this.layoutControl1.Controls.Add(this.txt_DC);
            this.layoutControl1.Controls.Add(this.txt_GT);
            this.layoutControl1.Controls.Add(this.txt_TenTT);
            this.layoutControl1.Controls.Add(this.txt_MaTT);
            this.layoutControl1.Location = new System.Drawing.Point(0, 5);
            this.layoutControl1.Margin = new System.Windows.Forms.Padding(4);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.layoutControlGroup1;
            this.layoutControl1.Size = new System.Drawing.Size(500, 240);
            this.layoutControl1.TabIndex = 1;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // txt_CV
            // 
            this.txt_CV.Location = new System.Drawing.Point(88, 180);
            this.txt_CV.Name = "txt_CV";
            this.txt_CV.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CV.Properties.Appearance.Options.UseFont = true;
            this.txt_CV.Size = new System.Drawing.Size(400, 24);
            this.txt_CV.StyleController = this.layoutControl1;
            this.txt_CV.TabIndex = 10;
            // 
            // txt_SDT
            // 
            this.txt_SDT.Location = new System.Drawing.Point(88, 152);
            this.txt_SDT.Name = "txt_SDT";
            this.txt_SDT.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SDT.Properties.Appearance.Options.UseFont = true;
            this.txt_SDT.Size = new System.Drawing.Size(400, 24);
            this.txt_SDT.StyleController = this.layoutControl1;
            this.txt_SDT.TabIndex = 9;
            // 
            // txt_DC
            // 
            this.txt_DC.Location = new System.Drawing.Point(88, 124);
            this.txt_DC.Name = "txt_DC";
            this.txt_DC.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DC.Properties.Appearance.Options.UseFont = true;
            this.txt_DC.Size = new System.Drawing.Size(400, 24);
            this.txt_DC.StyleController = this.layoutControl1;
            this.txt_DC.TabIndex = 8;
            // 
            // txt_GT
            // 
            this.txt_GT.Location = new System.Drawing.Point(88, 68);
            this.txt_GT.Name = "txt_GT";
            this.txt_GT.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_GT.Properties.Appearance.Options.UseFont = true;
            this.txt_GT.Size = new System.Drawing.Size(400, 24);
            this.txt_GT.StyleController = this.layoutControl1;
            this.txt_GT.TabIndex = 7;
            // 
            // txt_TenTT
            // 
            this.txt_TenTT.Location = new System.Drawing.Point(88, 40);
            this.txt_TenTT.Name = "txt_TenTT";
            this.txt_TenTT.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TenTT.Properties.Appearance.Options.UseFont = true;
            this.txt_TenTT.Size = new System.Drawing.Size(400, 24);
            this.txt_TenTT.StyleController = this.layoutControl1;
            this.txt_TenTT.TabIndex = 5;
            // 
            // txt_MaTT
            // 
            this.txt_MaTT.Location = new System.Drawing.Point(88, 12);
            this.txt_MaTT.Name = "txt_MaTT";
            this.txt_MaTT.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaTT.Properties.Appearance.Options.UseFont = true;
            this.txt_MaTT.Size = new System.Drawing.Size(400, 24);
            this.txt_MaTT.StyleController = this.layoutControl1;
            this.txt_MaTT.TabIndex = 4;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lbl_MaTT,
            this.lbl_TenTT,
            this.lbl_GT,
            this.lbl_DC,
            this.lbl_SDT,
            this.lbl_CV,
            this.lbl_NS});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "layoutControlGroup1";
            this.layoutControlGroup1.Size = new System.Drawing.Size(500, 240);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // lbl_MaTT
            // 
            this.lbl_MaTT.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MaTT.AppearanceItemCaption.Options.UseFont = true;
            this.lbl_MaTT.Control = this.txt_MaTT;
            this.lbl_MaTT.Location = new System.Drawing.Point(0, 0);
            this.lbl_MaTT.Name = "lbl_MaTT";
            this.lbl_MaTT.Size = new System.Drawing.Size(480, 28);
            this.lbl_MaTT.Text = "Mã thủ thư";
            this.lbl_MaTT.TextSize = new System.Drawing.Size(73, 17);
            // 
            // lbl_TenTT
            // 
            this.lbl_TenTT.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TenTT.AppearanceItemCaption.Options.UseFont = true;
            this.lbl_TenTT.Control = this.txt_TenTT;
            this.lbl_TenTT.Location = new System.Drawing.Point(0, 28);
            this.lbl_TenTT.Name = "lbl_TenTT";
            this.lbl_TenTT.Size = new System.Drawing.Size(480, 28);
            this.lbl_TenTT.Text = "Họ tên";
            this.lbl_TenTT.TextSize = new System.Drawing.Size(73, 17);
            // 
            // lbl_GT
            // 
            this.lbl_GT.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GT.AppearanceItemCaption.Options.UseFont = true;
            this.lbl_GT.Control = this.txt_GT;
            this.lbl_GT.Location = new System.Drawing.Point(0, 56);
            this.lbl_GT.Name = "lbl_GT";
            this.lbl_GT.Size = new System.Drawing.Size(480, 28);
            this.lbl_GT.Text = "Giới tính";
            this.lbl_GT.TextSize = new System.Drawing.Size(73, 17);
            // 
            // lbl_DC
            // 
            this.lbl_DC.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DC.AppearanceItemCaption.Options.UseFont = true;
            this.lbl_DC.Control = this.txt_DC;
            this.lbl_DC.Location = new System.Drawing.Point(0, 112);
            this.lbl_DC.Name = "lbl_DC";
            this.lbl_DC.Size = new System.Drawing.Size(480, 28);
            this.lbl_DC.Text = "Địa chỉ";
            this.lbl_DC.TextSize = new System.Drawing.Size(73, 17);
            // 
            // lbl_SDT
            // 
            this.lbl_SDT.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SDT.AppearanceItemCaption.Options.UseFont = true;
            this.lbl_SDT.Control = this.txt_SDT;
            this.lbl_SDT.Location = new System.Drawing.Point(0, 140);
            this.lbl_SDT.Name = "lbl_SDT";
            this.lbl_SDT.Size = new System.Drawing.Size(480, 28);
            this.lbl_SDT.Text = "Điện thoại";
            this.lbl_SDT.TextSize = new System.Drawing.Size(73, 17);
            // 
            // lbl_CV
            // 
            this.lbl_CV.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CV.AppearanceItemCaption.Options.UseFont = true;
            this.lbl_CV.Control = this.txt_CV;
            this.lbl_CV.Location = new System.Drawing.Point(0, 168);
            this.lbl_CV.Name = "lbl_CV";
            this.lbl_CV.Size = new System.Drawing.Size(480, 52);
            this.lbl_CV.Text = "Chức vụ";
            this.lbl_CV.TextSize = new System.Drawing.Size(73, 17);
            // 
            // txt_NS
            // 
            this.txt_NS.EditValue = null;
            this.txt_NS.Location = new System.Drawing.Point(88, 96);
            this.txt_NS.Name = "txt_NS";
            this.txt_NS.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NS.Properties.Appearance.Options.UseFont = true;
            this.txt_NS.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txt_NS.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txt_NS.Size = new System.Drawing.Size(400, 24);
            this.txt_NS.StyleController = this.layoutControl1;
            this.txt_NS.TabIndex = 11;
            // 
            // lbl_NS
            // 
            this.lbl_NS.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NS.AppearanceItemCaption.Options.UseFont = true;
            this.lbl_NS.Control = this.txt_NS;
            this.lbl_NS.Location = new System.Drawing.Point(0, 84);
            this.lbl_NS.Name = "lbl_NS";
            this.lbl_NS.Size = new System.Drawing.Size(480, 28);
            this.lbl_NS.Text = "Ngày sinh";
            this.lbl_NS.TextSize = new System.Drawing.Size(73, 17);
            // 
            // frm_TTTT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(509, 233);
            this.Controls.Add(this.layoutControl1);
            this.Name = "frm_TTTT";
            this.Text = "Thông tin Thủ thư";
            this.Load += new System.EventHandler(this.frm_TTTT_Load);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txt_CV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_DC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_GT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TenTT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaTT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_MaTT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_TenTT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_GT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_DC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_SDT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_CV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NS.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_NS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        public DevExpress.XtraEditors.TextEdit txt_CV;
        public DevExpress.XtraEditors.TextEdit txt_SDT;
        public DevExpress.XtraEditors.TextEdit txt_DC;
        public DevExpress.XtraEditors.TextEdit txt_GT;
        public DevExpress.XtraEditors.TextEdit txt_TenTT;
        public DevExpress.XtraEditors.TextEdit txt_MaTT;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        public DevExpress.XtraLayout.LayoutControlItem lbl_MaTT;
        public DevExpress.XtraLayout.LayoutControlItem lbl_TenTT;
        public DevExpress.XtraLayout.LayoutControlItem lbl_GT;
        public DevExpress.XtraLayout.LayoutControlItem lbl_DC;
        public DevExpress.XtraLayout.LayoutControlItem lbl_SDT;
        public DevExpress.XtraLayout.LayoutControlItem lbl_CV;
        private DevExpress.XtraEditors.DateEdit txt_NS;
        private DevExpress.XtraLayout.LayoutControlItem lbl_NS;
    }
}