﻿namespace QLThuVien.GUI
{
    partial class frm_PN
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_PN));
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.cmb_NCC = new System.Windows.Forms.ComboBox();
            this.cmb_TenTS = new System.Windows.Forms.ComboBox();
            this.cmb_TenTT = new System.Windows.Forms.ComboBox();
            this.txt_Tong = new DevExpress.XtraEditors.TextEdit();
            this.txt_TT = new DevExpress.XtraEditors.TextEdit();
            this.txt_Gia = new DevExpress.XtraEditors.TextEdit();
            this.txt_SL = new DevExpress.XtraEditors.TextEdit();
            this.date_NL = new DevExpress.XtraEditors.DateEdit();
            this.txt_MaPN = new DevExpress.XtraEditors.TextEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.lci_MaPN = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_SL = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_NL = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_Gia = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_Tong = new DevExpress.XtraLayout.LayoutControlItem();
            this.lbl_TS = new DevExpress.XtraLayout.LayoutControlItem();
            this.lbl_NCC = new DevExpress.XtraLayout.LayoutControlItem();
            this.lbl_TT = new DevExpress.XtraLayout.LayoutControlItem();
            this.lci_TT = new DevExpress.XtraLayout.LayoutControlItem();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btn_cancel = new DevExpress.XtraEditors.SimpleButton();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.btn_save = new DevExpress.XtraEditors.SimpleButton();
            this.btn_delete = new DevExpress.XtraEditors.SimpleButton();
            this.btn_update = new DevExpress.XtraEditors.SimpleButton();
            this.btn_insert = new DevExpress.XtraEditors.SimpleButton();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Tong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Gia.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_NL.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_NL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaPN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_MaPN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_SL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_NL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_Gia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_Tong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_TS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_NCC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_TT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_TT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // layoutControl1
            // 
            this.layoutControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.layoutControl1.Controls.Add(this.cmb_NCC);
            this.layoutControl1.Controls.Add(this.cmb_TenTS);
            this.layoutControl1.Controls.Add(this.cmb_TenTT);
            this.layoutControl1.Controls.Add(this.txt_Tong);
            this.layoutControl1.Controls.Add(this.txt_TT);
            this.layoutControl1.Controls.Add(this.txt_Gia);
            this.layoutControl1.Controls.Add(this.txt_SL);
            this.layoutControl1.Controls.Add(this.date_NL);
            this.layoutControl1.Controls.Add(this.txt_MaPN);
            this.layoutControl1.Location = new System.Drawing.Point(20, 7);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.layoutControlGroup1;
            this.layoutControl1.Size = new System.Drawing.Size(857, 149);
            this.layoutControl1.TabIndex = 0;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // cmb_NCC
            // 
            this.cmb_NCC.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_NCC.FormattingEnabled = true;
            this.cmb_NCC.Location = new System.Drawing.Point(472, 40);
            this.cmb_NCC.Name = "cmb_NCC";
            this.cmb_NCC.Size = new System.Drawing.Size(373, 25);
            this.cmb_NCC.TabIndex = 16;
            // 
            // cmb_TenTS
            // 
            this.cmb_TenTS.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_TenTS.FormattingEnabled = true;
            this.cmb_TenTS.Location = new System.Drawing.Point(102, 65);
            this.cmb_TenTS.Name = "cmb_TenTS";
            this.cmb_TenTS.Size = new System.Drawing.Size(743, 25);
            this.cmb_TenTS.TabIndex = 15;
            // 
            // cmb_TenTT
            // 
            this.cmb_TenTT.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_TenTT.FormattingEnabled = true;
            this.cmb_TenTT.Location = new System.Drawing.Point(102, 40);
            this.cmb_TenTT.Name = "cmb_TenTT";
            this.cmb_TenTT.Size = new System.Drawing.Size(276, 25);
            this.cmb_TenTT.TabIndex = 14;
            // 
            // txt_Tong
            // 
            this.txt_Tong.Enabled = false;
            this.txt_Tong.Location = new System.Drawing.Point(659, 12);
            this.txt_Tong.Name = "txt_Tong";
            this.txt_Tong.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Tong.Properties.Appearance.Options.UseFont = true;
            this.txt_Tong.Size = new System.Drawing.Size(186, 24);
            this.txt_Tong.StyleController = this.layoutControl1;
            this.txt_Tong.TabIndex = 13;
            // 
            // txt_TT
            // 
            this.txt_TT.Enabled = false;
            this.txt_TT.Location = new System.Drawing.Point(659, 90);
            this.txt_TT.Name = "txt_TT";
            this.txt_TT.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TT.Properties.Appearance.Options.UseFont = true;
            this.txt_TT.Size = new System.Drawing.Size(186, 24);
            this.txt_TT.StyleController = this.layoutControl1;
            this.txt_TT.TabIndex = 12;
            // 
            // txt_Gia
            // 
            this.txt_Gia.Location = new System.Drawing.Point(378, 90);
            this.txt_Gia.Name = "txt_Gia";
            this.txt_Gia.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Gia.Properties.Appearance.Options.UseFont = true;
            this.txt_Gia.Size = new System.Drawing.Size(187, 24);
            this.txt_Gia.StyleController = this.layoutControl1;
            this.txt_Gia.TabIndex = 11;
            // 
            // txt_SL
            // 
            this.txt_SL.Location = new System.Drawing.Point(102, 90);
            this.txt_SL.Name = "txt_SL";
            this.txt_SL.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SL.Properties.Appearance.Options.UseFont = true;
            this.txt_SL.Size = new System.Drawing.Size(182, 24);
            this.txt_SL.StyleController = this.layoutControl1;
            this.txt_SL.TabIndex = 10;
            // 
            // date_NL
            // 
            this.date_NL.EditValue = null;
            this.date_NL.Location = new System.Drawing.Point(378, 12);
            this.date_NL.Name = "date_NL";
            this.date_NL.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_NL.Properties.Appearance.Options.UseFont = true;
            this.date_NL.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.date_NL.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.date_NL.Size = new System.Drawing.Size(187, 24);
            this.date_NL.StyleController = this.layoutControl1;
            this.date_NL.TabIndex = 8;
            // 
            // txt_MaPN
            // 
            this.txt_MaPN.Enabled = false;
            this.txt_MaPN.Location = new System.Drawing.Point(102, 12);
            this.txt_MaPN.Name = "txt_MaPN";
            this.txt_MaPN.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaPN.Properties.Appearance.Options.UseFont = true;
            this.txt_MaPN.Size = new System.Drawing.Size(182, 24);
            this.txt_MaPN.StyleController = this.layoutControl1;
            this.txt_MaPN.TabIndex = 4;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lci_MaPN,
            this.lci_SL,
            this.lci_NL,
            this.lci_Gia,
            this.lci_Tong,
            this.lbl_TS,
            this.lbl_NCC,
            this.lbl_TT,
            this.lci_TT});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "layoutControlGroup1";
            this.layoutControlGroup1.Size = new System.Drawing.Size(857, 149);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // lci_MaPN
            // 
            this.lci_MaPN.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_MaPN.AppearanceItemCaption.Options.UseFont = true;
            this.lci_MaPN.Control = this.txt_MaPN;
            this.lci_MaPN.Location = new System.Drawing.Point(0, 0);
            this.lci_MaPN.Name = "lci_MaPN";
            this.lci_MaPN.Size = new System.Drawing.Size(276, 28);
            this.lci_MaPN.Text = "Mã PN";
            this.lci_MaPN.TextSize = new System.Drawing.Size(87, 17);
            // 
            // lci_SL
            // 
            this.lci_SL.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_SL.AppearanceItemCaption.Options.UseFont = true;
            this.lci_SL.Control = this.txt_SL;
            this.lci_SL.Location = new System.Drawing.Point(0, 78);
            this.lci_SL.Name = "lci_SL";
            this.lci_SL.Size = new System.Drawing.Size(276, 51);
            this.lci_SL.Text = "Số Lượng";
            this.lci_SL.TextSize = new System.Drawing.Size(87, 17);
            // 
            // lci_NL
            // 
            this.lci_NL.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_NL.AppearanceItemCaption.Options.UseFont = true;
            this.lci_NL.Control = this.date_NL;
            this.lci_NL.Location = new System.Drawing.Point(276, 0);
            this.lci_NL.Name = "lci_NL";
            this.lci_NL.Size = new System.Drawing.Size(281, 28);
            this.lci_NL.Text = "Ngày lập";
            this.lci_NL.TextSize = new System.Drawing.Size(87, 17);
            // 
            // lci_Gia
            // 
            this.lci_Gia.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_Gia.AppearanceItemCaption.Options.UseFont = true;
            this.lci_Gia.Control = this.txt_Gia;
            this.lci_Gia.Location = new System.Drawing.Point(276, 78);
            this.lci_Gia.Name = "lci_Gia";
            this.lci_Gia.Size = new System.Drawing.Size(281, 51);
            this.lci_Gia.Text = "Đơn giá";
            this.lci_Gia.TextSize = new System.Drawing.Size(87, 17);
            // 
            // lci_Tong
            // 
            this.lci_Tong.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_Tong.AppearanceItemCaption.Options.UseFont = true;
            this.lci_Tong.Control = this.txt_Tong;
            this.lci_Tong.Location = new System.Drawing.Point(557, 0);
            this.lci_Tong.Name = "lci_Tong";
            this.lci_Tong.Size = new System.Drawing.Size(280, 28);
            this.lci_Tong.Text = "Tổng tiền";
            this.lci_Tong.TextSize = new System.Drawing.Size(87, 17);
            // 
            // lbl_TS
            // 
            this.lbl_TS.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TS.AppearanceItemCaption.Options.UseFont = true;
            this.lbl_TS.Control = this.cmb_TenTS;
            this.lbl_TS.Location = new System.Drawing.Point(0, 53);
            this.lbl_TS.Name = "lbl_TS";
            this.lbl_TS.Size = new System.Drawing.Size(837, 25);
            this.lbl_TS.Text = "Tựa sách";
            this.lbl_TS.TextSize = new System.Drawing.Size(87, 17);
            // 
            // lbl_NCC
            // 
            this.lbl_NCC.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NCC.AppearanceItemCaption.Options.UseFont = true;
            this.lbl_NCC.Control = this.cmb_NCC;
            this.lbl_NCC.Location = new System.Drawing.Point(370, 28);
            this.lbl_NCC.Name = "lbl_NCC";
            this.lbl_NCC.Size = new System.Drawing.Size(467, 25);
            this.lbl_NCC.Text = "Nhà cung cấp";
            this.lbl_NCC.TextSize = new System.Drawing.Size(87, 17);
            // 
            // lbl_TT
            // 
            this.lbl_TT.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TT.AppearanceItemCaption.Options.UseFont = true;
            this.lbl_TT.Control = this.cmb_TenTT;
            this.lbl_TT.Location = new System.Drawing.Point(0, 28);
            this.lbl_TT.Name = "lbl_TT";
            this.lbl_TT.Size = new System.Drawing.Size(370, 25);
            this.lbl_TT.Text = "Tên TT";
            this.lbl_TT.TextSize = new System.Drawing.Size(87, 17);
            // 
            // lci_TT
            // 
            this.lci_TT.AppearanceItemCaption.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lci_TT.AppearanceItemCaption.Options.UseFont = true;
            this.lci_TT.Control = this.txt_TT;
            this.lci_TT.Location = new System.Drawing.Point(557, 78);
            this.lci_TT.Name = "lci_TT";
            this.lci_TT.Size = new System.Drawing.Size(280, 51);
            this.lci_TT.Text = "Thành tiền";
            this.lci_TT.TextSize = new System.Drawing.Size(87, 17);
            // 
            // panelControl1
            // 
            this.panelControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl1.Appearance.BackColor = System.Drawing.Color.White;
            this.panelControl1.Appearance.Options.UseBackColor = true;
            this.panelControl1.Controls.Add(this.btn_cancel);
            this.panelControl1.Controls.Add(this.txt_search);
            this.panelControl1.Controls.Add(this.btn_save);
            this.panelControl1.Controls.Add(this.btn_delete);
            this.panelControl1.Controls.Add(this.btn_update);
            this.panelControl1.Controls.Add(this.btn_insert);
            this.panelControl1.Location = new System.Drawing.Point(29, 162);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(837, 59);
            this.panelControl1.TabIndex = 7;
            // 
            // btn_cancel
            // 
            this.btn_cancel.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.Appearance.Options.UseFont = true;
            this.btn_cancel.Image = ((System.Drawing.Image)(resources.GetObject("btn_cancel.Image")));
            this.btn_cancel.Location = new System.Drawing.Point(426, 12);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(100, 35);
            this.btn_cancel.TabIndex = 19;
            this.btn_cancel.Text = "CANCEL";
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // txt_search
            // 
            this.txt_search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_search.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txt_search.Location = new System.Drawing.Point(532, 12);
            this.txt_search.Multiline = true;
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(285, 35);
            this.txt_search.TabIndex = 17;
            this.txt_search.Text = "Search";
            this.txt_search.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txt_search_MouseClick);
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // btn_save
            // 
            this.btn_save.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Appearance.Options.UseFont = true;
            this.btn_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_save.Image")));
            this.btn_save.Location = new System.Drawing.Point(320, 12);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(100, 35);
            this.btn_save.TabIndex = 15;
            this.btn_save.Text = "SAVE";
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Appearance.Options.UseFont = true;
            this.btn_delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_delete.Image")));
            this.btn_delete.Location = new System.Drawing.Point(214, 12);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(100, 35);
            this.btn_delete.TabIndex = 14;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Appearance.Options.UseFont = true;
            this.btn_update.Image = ((System.Drawing.Image)(resources.GetObject("btn_update.Image")));
            this.btn_update.Location = new System.Drawing.Point(108, 12);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(100, 35);
            this.btn_update.TabIndex = 13;
            this.btn_update.Text = "UPDATE";
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_insert.Appearance.Options.UseFont = true;
            this.btn_insert.Image = ((System.Drawing.Image)(resources.GetObject("btn_insert.Image")));
            this.btn_insert.Location = new System.Drawing.Point(2, 12);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(100, 35);
            this.btn_insert.TabIndex = 12;
            this.btn_insert.Text = "INSERT";
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // gridControl1
            // 
            this.gridControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridControl1.Location = new System.Drawing.Point(29, 227);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(837, 200);
            this.gridControl1.TabIndex = 8;
            this.gridControl1.UseEmbeddedNavigator = true;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Appearance.GroupRow.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridView1.Appearance.GroupRow.Options.UseFont = true;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn9,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn10});
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.GroupCount = 2;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsView.ShowFooter = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn1, DevExpress.Data.ColumnSortOrder.Ascending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn10, DevExpress.Data.ColumnSortOrder.Ascending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn5, DevExpress.Data.ColumnSortOrder.Ascending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn9, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridView1.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridView1_FocusedRowChanged);
            this.gridView1.Click += new System.EventHandler(this.gridView1_Click);
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn1.AppearanceCell.Options.UseFont = true;
            this.gridColumn1.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn1.AppearanceHeader.Options.UseFont = true;
            this.gridColumn1.Caption = "Mã PN";
            this.gridColumn1.FieldName = "MaPN";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 77;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn9.AppearanceCell.Options.UseFont = true;
            this.gridColumn9.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn9.AppearanceHeader.Options.UseFont = true;
            this.gridColumn9.Caption = "Mã Tựa sách";
            this.gridColumn9.FieldName = "MaTS";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 0;
            this.gridColumn9.Width = 85;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn2.AppearanceCell.Options.UseFont = true;
            this.gridColumn2.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn2.AppearanceHeader.Options.UseFont = true;
            this.gridColumn2.Caption = "Tên Thủ thư";
            this.gridColumn2.FieldName = "TenTT";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            this.gridColumn2.Width = 137;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn3.AppearanceCell.Options.UseFont = true;
            this.gridColumn3.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn3.AppearanceHeader.Options.UseFont = true;
            this.gridColumn3.Caption = "Tên NCC";
            this.gridColumn3.FieldName = "TenNCC";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 3;
            this.gridColumn3.Width = 107;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn4.AppearanceCell.Options.UseFont = true;
            this.gridColumn4.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn4.AppearanceHeader.Options.UseFont = true;
            this.gridColumn4.Caption = "Ngày lập";
            this.gridColumn4.FieldName = "NgayLap";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            this.gridColumn4.Width = 69;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn5.AppearanceCell.Options.UseFont = true;
            this.gridColumn5.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn5.AppearanceHeader.Options.UseFont = true;
            this.gridColumn5.Caption = "Tựa sách";
            this.gridColumn5.FieldName = "TenTS";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 1;
            this.gridColumn5.Width = 147;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn6.AppearanceCell.Options.UseFont = true;
            this.gridColumn6.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn6.AppearanceHeader.Options.UseFont = true;
            this.gridColumn6.Caption = "Số lượng";
            this.gridColumn6.FieldName = "SoLuong";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 5;
            this.gridColumn6.Width = 65;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn7.AppearanceCell.Options.UseFont = true;
            this.gridColumn7.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn7.AppearanceHeader.Options.UseFont = true;
            this.gridColumn7.Caption = "Đơn giá";
            this.gridColumn7.FieldName = "DonGia";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 6;
            this.gridColumn7.Width = 96;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn8.AppearanceCell.Options.UseFont = true;
            this.gridColumn8.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn8.AppearanceHeader.Options.UseFont = true;
            this.gridColumn8.Caption = "Thành tiền";
            this.gridColumn8.FieldName = "TT";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TT", "Tổng={0:0.##}")});
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 7;
            this.gridColumn8.Width = 113;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn10.AppearanceCell.Options.UseFont = true;
            this.gridColumn10.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn10.AppearanceHeader.Options.UseFont = true;
            this.gridColumn10.Caption = "Tổng tiền";
            this.gridColumn10.FieldName = "TongTien";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 8;
            // 
            // frm_PN
            // 
            this.Appearance.BackColor = System.Drawing.Color.White;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.layoutControl1);
            this.Name = "frm_PN";
            this.Size = new System.Drawing.Size(900, 450);
            this.Load += new System.EventHandler(this.frm_PN_Load);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txt_Tong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Gia.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_NL.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_NL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaPN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_MaPN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_SL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_NL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_Gia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_Tong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_TS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_NCC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_TT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci_TT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraEditors.DateEdit date_NL;
        private DevExpress.XtraEditors.TextEdit txt_MaPN;
        private DevExpress.XtraLayout.LayoutControlItem lci_MaPN;
        private DevExpress.XtraLayout.LayoutControlItem lci_NL;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private System.Windows.Forms.TextBox txt_search;
        private DevExpress.XtraEditors.SimpleButton btn_save;
        private DevExpress.XtraEditors.SimpleButton btn_delete;
        private DevExpress.XtraEditors.SimpleButton btn_update;
        private DevExpress.XtraEditors.SimpleButton btn_insert;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraEditors.TextEdit txt_Tong;
        private DevExpress.XtraEditors.TextEdit txt_TT;
        private DevExpress.XtraEditors.TextEdit txt_Gia;
        private DevExpress.XtraEditors.TextEdit txt_SL;
        private DevExpress.XtraLayout.LayoutControlItem lci_SL;
        private DevExpress.XtraLayout.LayoutControlItem lci_Tong;
        private DevExpress.XtraLayout.LayoutControlItem lci_Gia;
        private DevExpress.XtraLayout.LayoutControlItem lci_TT;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraEditors.SimpleButton btn_cancel;
        private System.Windows.Forms.ComboBox cmb_NCC;
        private System.Windows.Forms.ComboBox cmb_TenTS;
        private System.Windows.Forms.ComboBox cmb_TenTT;
        private DevExpress.XtraLayout.LayoutControlItem lbl_TT;
        private DevExpress.XtraLayout.LayoutControlItem lbl_TS;
        private DevExpress.XtraLayout.LayoutControlItem lbl_NCC;
    }
}
